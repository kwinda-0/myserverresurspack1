global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ywAngle = (mainHand and yawAngle) or yawAngleO
local ptAngle = (mainHand and pitchAngle) or pitchAngleO

local hand = (bl and 1) or -1

if I:isOf(item, Items:get("minecraft:bordure_indented_banner_pattern")) or I:isOf(item, Items:get("minecraft:creeper_banner_pattern")) or I:isOf(item, Items:get("minecraft:piglin_banner_pattern")) or I:isOf(item, Items:get("minecraft:flower_banner_pattern")) or I:isOf(item, Items:get("minecraft:field_masoned_banner_pattern")) or I:isOf(item, Items:get("minecraft:skull_banner_pattern")) or I:isOf(item, Items:get("minecraft:mojang_banner_pattern")) or I:isOf(item, Items:get("minecraft:guster_banner_pattern")) or I:isOf(item, Items:get("minecraft:globe_banner_pattern")) or I:isOf(item, Items:get("minecraft:flow_banner_pattern")) then
    M:moveY(matrices, -0.2)
    M:rotateX(matrices, -70)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle + ywAngle * 0.5, 0, -0.13, 0)
end

if I:isOf(item, Items:get("minecraft:name_tag")) then
    M:moveY(matrices, -0.2)
    M:moveX(matrices, -0.04)
    M:rotateX(matrices, -70)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle + ywAngle * 0.5, 0, -0.13, 0)
end

if I:isOf(item, Items:get("minecraft:paper")) then
    M:moveY(matrices, 0.06)
    M:moveZ(matrices, 0.06)
    M:rotateX(matrices, 5)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 10, -5, 10) + ptAngle)
end